<?php

namespace App\Controller\Admin;

/**
 * @property \Cake\ORM\Table $CampaignCountries
 */
class CampaignCountriesController extends AppAdminController
{
}
